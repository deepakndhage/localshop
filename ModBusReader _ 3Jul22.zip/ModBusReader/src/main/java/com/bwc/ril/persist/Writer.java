/**
 * 
 */
package com.bwc.ril.persist;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.bwc.ril.entity.WMSRawData;
import com.bwc.ril.repository.WMSRawDataRepository;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author deepak
 * The class for persisting data in database 
 *
 */
@Service
public class Writer {
	
	@Autowired
	private WMSRawDataRepository wmsRawDataRepo;
	
	 private final Logger logger = LoggerFactory.getLogger(Writer.class);

	 /*
	  * The method will write data to database after doing validatioins.
	  * Returns WMSRawData 
	  *
	  */
	public WMSRawData write(WMSRawData rawData) throws Exception {
		logger.debug("Raw data to be created - rawData");
		if (rawData == null) {
			
			logger.error("Raw data is null.");
			
			// todo: Replace with custom exception - if needed.
			throw new Exception("Raw data is null.");
			
		}
		if(!StringUtils.hasText(rawData.getValu())) {
			logger.error("Value for tag "+rawData.getTagName()+" is null.");
			throw new Exception("Value for tag "+rawData.getTagName()+" is null.");
		}
		// what are other validations on raw data fields? can value be null or empty
		
		WMSRawData data = wmsRawDataRepo.save(rawData);
		logger.debug("Created raw data record - "+data);
		return data;
	}
}
