/**
 * 
 */
package com.bwc.ril.entity;

import java.sql.Timestamp;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;


/**
 * @author deepak
 *
 */
@Entity
public class WMSRawData {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private String tagName;
	private Timestamp timeStamp;
	private String valu;
	private String status;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getTagName() {
		return tagName;
	}
	public void setTagName(String tagName) {
		this.tagName = tagName;
	}
	public Timestamp getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(Timestamp timeStamp) {
		this.timeStamp = timeStamp;
	}
	public String getValu() {
		return valu;
	}
	public void setValu(String value) {
		this.valu = value;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	@Override
	public String toString() {
		return "WMSRawData [id=" + id + ", tagName=" + tagName + ", timeStamp=" + timeStamp + ", value=" + valu
				+ ", status=" + status + "]";
	}
	
	

}
