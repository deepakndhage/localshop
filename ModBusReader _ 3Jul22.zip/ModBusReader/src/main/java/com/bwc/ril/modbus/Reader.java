/**
 * 
 */
package com.bwc.ril.modbus;

import java.net.InetAddress;
import java.util.concurrent.CompletableFuture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.digitalpetri.modbus.master.ModbusTcpMaster;
import com.digitalpetri.modbus.master.ModbusTcpMasterConfig;
import com.digitalpetri.modbus.requests.ReadHoldingRegistersRequest;
import com.digitalpetri.modbus.responses.ReadHoldingRegistersResponse;

import de.re.easymodbus.modbusclient.ModbusClient;
import io.netty.buffer.ByteBufUtil;
import io.netty.util.ReferenceCountUtil;
import net.wimpi.modbus.io.ModbusTCPTransaction;
import net.wimpi.modbus.msg.ReadInputRegistersRequest;
import net.wimpi.modbus.msg.ReadInputRegistersResponse;
import net.wimpi.modbus.net.TCPMasterConnection;

/**
 * @author deepak
 * The class reads data from ModBus 
 */
@Service
public class Reader {
	
	private final Logger logger = LoggerFactory.getLogger(Reader.class);
	
	 /* The important instances of the class */
    TCPMasterConnection con = null; // the connection
    ModbusTCPTransaction trans = null; // the transaction
    ReadInputRegistersRequest rreq = null; // the read request
    ReadInputRegistersResponse  rres = null; // the read response
   
    
    /* Variables for storing the parameters */
    InetAddress addr = null; // the slave's address
    int port = 502; // the default port

   

    
	// initialise modbus connector
	
	
    /*
     * Read the data from ModBus using wimpi library - basic code- need to handle all cases manually.
     */
	public  String  read() {
		
		// use modbus connector to read data
		logger.debug("Raw data to be read using read method --- start");
		
		 // 1. Setup the parameters
	    try {
			addr = InetAddress.getByName("127.0.0.1");
			 // 2. Open the connection
            con = new TCPMasterConnection(addr);
            con.setPort(port);
            con.connect();
            logger.debug( "--- connected --- " );
            
         // ~~~~~~~~~~~~~~~~~~~~ The faulty Read Request ~~~~~~~~~~~~~~~~~~~~
            // 3r. Prepare the READ request
            int k = 40001; 
            rreq = new ReadInputRegistersRequest(k, 2); // Reading 8 bytes (of
                                                        // what??)

            // 4r. Prepare the READ transaction
            trans = new ModbusTCPTransaction(con);
            trans.setRequest(rreq);
            
            // 5r. Execute the READ transaction
            trans.execute();
            logger.debug( "--- Request made  --- " );
            rres = (ReadInputRegistersResponse) trans.getResponse();
            logger.debug("Hex Value of register " + "= "
                    + rres.getHexMessage());
            return rres.getHexMessage();
            
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error("Unable to read from Modbus", e);
			e.printStackTrace();
		} // ** The address
	                                                    // assigned to the
	                                                    // module **
	    logger.debug("Raw data to be read using read method --- end");
		
		// handle timeout  
		
		// handle error
		
		// handle corrupt data
	
		// are there business validations?
		
		// do we have to validate if same data is repeating? if yes, should we just write it or reject?
		
		// use write to write
		
	    return "";
		
	}
	
	
	/*
     * Read the data from ModBus using digitalpetri library - async high performance.
     */
	public  String  read2() {
		
		logger.debug("Raw data to be read using read2 method --- start");
		
		ModbusTcpMasterConfig config = new ModbusTcpMasterConfig.Builder("127.0.0.1").build();
		ModbusTcpMaster master = new ModbusTcpMaster(config);

		master.connect();
		logger.debug( "--- connected --- " );
		CompletableFuture<ReadHoldingRegistersResponse> future =
		    master.sendRequest(new ReadHoldingRegistersRequest(0, 4), 0);
		logger.debug( "--- Request made  --- " );
		future.thenAccept(response -> {
		    System.out.println("Response: " + ByteBufUtil.hexDump(response.getRegisters()));
		logger.debug("Value from register "+ByteBufUtil.hexDump(response.getRegisters()));
		    ReferenceCountUtil.release(response);
		});
		logger.debug("Raw data to be read using read2 method --- end");
	    return "";
		
	}
	/*
     * Read the data from ModBus using easyModBus liibrary
     */
	public String read3() throws Exception {
		logger.debug("Raw data to be read using read3 method --- start");
		ModbusClient client = new ModbusClient();
		client.Connect("127.0.0.1", 502);
		logger.debug( "--- connected --- " );
		int[] holdingRegisters = client.ReadHoldingRegisters(0, 4);
		logger.debug( "--- Request made  --- " );
		for(int index=0; index<holdingRegisters.length; index++) {
			logger.debug("Value from Register "+(index+1)+" - "+holdingRegisters[index]);
		}
		logger.debug("Raw data to be read using read3 method --- end");
		return "";
	}

}
