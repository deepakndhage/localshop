package com.bwc.ril;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ModBusReaderApplicationTests {

	@Test
	void contextLoads() {
	}

}
