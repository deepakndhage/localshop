/**
 * 
 */
package com.bwc.ril;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import com.bwc.ril.entity.WMSRawData;
import com.bwc.ril.modbus.Reader;
import com.bwc.ril.persist.Writer;

/**
 * @author deepak
 * Serves the purpose of periodically reading from ModBus and persisting to DB
 */
@Configuration
@EnableScheduling
@EnableAsync
public class Executor {
	
	@Autowired
	Reader reader;
	
	@Autowired
	Writer writer;
	
	private final Logger logger = LoggerFactory.getLogger(Executor.class);
			
	/*
	 * Execute method runs every 1 minute and read the data from ModBus and writes to DB.
	 * 
	 */
	@Async
    @Scheduled(fixedRate = 60000, initialDelay = 1000)
	public void execute() {
		System.out.println(
			      "Fixed rate task - " + System.currentTimeMillis() / 1000);
		
		logger.debug("Fixed rate task - " + System.currentTimeMillis() / 1000);
		
		reader.read();
		
		reader.read2();
		
		try {
			reader.read3();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		WMSRawData rawData = null;//Create object from data string 
		
		/*
		 // test the writer without reader
		WMSRawData rawData = new WMSRawData();
		data.setStatus("active");
		data.setTagName("test tag");
		data.setValu("value 1");
		*/
		
		/*
		try {
			rawData = writer.write(rawData);
			System.out.println(
				      "data - " + rawData);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error("Unable to write  to DB",e);
			e.printStackTrace();
		}
		*/
		// writter.save(rawData);
		
	}
}
