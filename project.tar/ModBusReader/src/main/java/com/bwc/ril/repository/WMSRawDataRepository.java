/**
 * 
 */
package com.bwc.ril.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bwc.ril.entity.WMSRawData;

/**
 * @author deepak
 *
 */
public interface WMSRawDataRepository extends JpaRepository<WMSRawData, Long> {

}
