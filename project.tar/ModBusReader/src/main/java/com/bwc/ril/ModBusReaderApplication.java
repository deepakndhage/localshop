package com.bwc.ril;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ModBusReaderApplication {

	public static void main(String[] args) {
		SpringApplication.run(ModBusReaderApplication.class, args);
	}

}
